# Meadow review package

For the five-minute review on 14 October 2026.

## Open these

- **Meadow-review.pdf**: ready-to-present copy. It preserves the approved typography without font installation. Pages are flattened images, not editable text.
- **Meadow-review.pptx**: editable five-slide deck with timed speaker notes. Install the included fonts before editing or presenting this version if your app substitutes them.
- **DEMO-GUIDE.md**: setup checklist, exact five-minute script, Chrome clicks, recovery steps and reviewer Q&A.
- **brand-sheet.html**: visual identity sheet. Open in a browser, with this folder intact.
- **BRAND-GUIDE.md**: typography, colors, illustration treatment and wording rules.
- **slide-backup/**: five PNGs for presentation fallback.
- **assets/**: real screenshots of the tested build for demo fallback.
- **fonts/**: Rajdhani and Inter with licenses.

## Refresh the product

The project has been renamed **Meadow 1.1.0**. Go to `chrome://extensions`, reload the installed extension, and refresh the demo tabs. Chrome does not automatically reload unpacked extension files after edits.

The existing folder paths intentionally remain stable:

```
/Users/pawanyadav/Documents/Codex/2026-10-08/th/outputs/shopcheck/dist/shopcheck-demo
/Users/pawanyadav/Documents/Codex/2026-10-08/th/outputs/shopcheck/dist/shopcheck
```

Use Demo Lab for the review. Use the live build for everyday shopping. Enable only one at a time. The source and versioned releases are in the sibling `shopcheck` folder.

## Demo in one sentence

Show the actual extension change from **REVIEW** to **HIGH RISK** when an unsafe checkout appears, then show that a new independent shop remains **REVIEW**.

The local demo does not require internet. Registration ages are explicit fixtures. Local HTTP remains a real warning. This demonstration establishes selected implementation behaviours, not real-world fraud detection accuracy.
