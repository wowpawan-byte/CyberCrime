# Meadow: the five-minute review

14 October 2026, around 1:30 as supplied. Confirm the room and AM/PM with the reviewer. This package does not schedule a reminder.

## The promise

“Meadow gives shoppers a first check of an unfamiliar store, with visible reasons to pause before entering details.”

Demonstrate one dangerous condition and one restrained decision. Do not describe Meadow as a complete fraud solution, a guarantee, or a proven accuracy benchmark.

## Before the review

1. For the simplest presentation, open `Meadow-review.pdf` in Preview and use full screen. It needs no installed fonts. For the editable PowerPoint version with speaker notes, install Rajdhani SemiBold and Inter from `fonts` in Font Book if needed, then restart PowerPoint/Keynote. Keep `slide-backup` nearby as another font-independent fallback.
2. In Chrome, open `chrome://extensions`. Reload the unpacked **Meadow · Demo Lab** extension. If the old name remains, reload again and confirm version **1.1.0**. The folder is still `outputs/shopcheck/dist/shopcheck-demo` inside this workspace. Keeping the path preserves the existing installation.
3. Disable the everyday/live copy for the demonstration to avoid two notices. Do not delete it. Pin the Demo Lab extension in Chrome’s toolbar. Refresh already-open demo pages after reloading the extension.
4. Start the server in Terminal:

```sh
cd /Users/pawanyadav/Documents/Codex/2026-10-08/th/outputs/shopcheck
npm run demo
```

Keep that Terminal open. If port 8765 is occupied and the demo already opens, use the running server. Do not stop unrelated processes.

5. Prepare exactly two Chrome tabs:
   - `http://checkout-store.localhost:8765/`
   - `http://new-store.localhost:8765/`
6. Reset the first scenario. The initial result should be **REVIEW**. Keep registration lookup and on-page warnings enabled for this rehearsal. The labelled local fixtures need no external registry connection.
7. Open the deck in full-screen presentation mode. Rehearse switching between the deck and Chrome with Command-Tab. Use Do Not Disturb and close personal tabs.
8. Test projection from the back of the room. Browser zoom can enlarge the page preview but may not enlarge Chrome’s toolbar popup. Use the actual popup at least once, then the clearly labelled preview for distant readers. Do not describe that page preview as browser-injected UI.

## Run of show

| Time | Screen | What to say or do |
|---|---|---|
| 0:00–0:30 | Slide 1 | “Would you buy from this store?” Pause. “Appearance alone cannot tell us who controls the address or how the checkout handles sensitive details.” |
| 0:30–1:10 | Slide 2 | “Meadow shows an observable reason to pause. Here, sensitive fields appear on an unencrypted page. The warning explains the condition. It does not prove the seller’s identity or intent.” |
| 1:10–1:45 | Slide 3 | “It checks automatically. One click gives the reasons. We use a small set of understandable rules, no model and no account. Unknown information stays unknown.” |
| 1:45–2:00 | Slide 4 | “Let’s watch the evidence change when checkout appears, then see how Meadow treats a new shop.” Switch to Chrome. |
| 2:00–2:25 | Checkout tab | Open the pinned extension. Show **REVIEW** and the actual domain. Explain that local HTTP already deserves caution. Close the popup. |
| 2:25–3:15 | Same tab | Click **Proceed to checkout**. Pause for the rescan. Open the toolbar popup: **HIGH RISK**. Expand **Connection & forms**. “Sensitive fields are now visible on HTTP. That observed condition triggers the stronger warning.” |
| 3:15–3:40 | New-shop tab | Open the popup and **Registration age**. Show **REVIEW**. “A new shop is not automatically fraudulent. Age alone does not trigger High Risk.” Mention this local page also uses HTTP. |
| 3:40–4:00 | Chrome | “Registration ages here are labelled test fixtures. The browser inspects the actual page. Inputs are disabled, and we send no payment.” Return to the deck. |
| 4:00–4:45 | Slide 5 | “The value is a reason to reconsider before giving details. Meadow is a first check. It cannot guarantee the seller is genuine or that an order will arrive. We make the evidence easier to notice and understand.” |
| 4:45–5:00 | Slide 5 | Buffer for switching or one closing sentence. Do not start an extra scenario. |

## Recovery without losing the room

- **No toolbar update:** refresh the page, wait, then open the popup. Use “Check again” once. Confirm the Demo Lab build, not the live build. Do not troubleshoot repeatedly during the five minutes.
- **Server missing:** start the command above. If that takes more than 15 seconds, use the screenshot fallback.
- **Font substitution or deck app trouble:** show the five PNGs in `slide-backup` using Preview. These preserve the intended typography.
- **Demo trouble:** open the saved `assets/review-before.png`, then `assets/popup.png`, then `assets/new-store-review.png`. Say: “These are screenshots of the tested run.” Do not pretend they are live.
- **Internet trouble:** the two selected local scenarios do not need internet. Real registration lookups may return Unknown. That is a valid, visible limitation, not evidence of fraud.

## Likely questions

**What exactly is novel?**

Our contribution is integration and interaction design: surface the actual domain, group concrete evidence, reserve strong warnings for explicit dangerous conditions or defined combinations, and make uncertainty readable. The underlying methods already exist. We do not claim a newly invented algorithm or globally unique product.

**How does it work without AI?**

Domain parsing, a curated catalogue of covered brands/processors, optional registration lookup and page inspection feed deterministic rules. Seven displayed categories explain the result. No model training, model API or backend account is involved.

**How effective is it?**

The live test demonstrates detection of the specific unsafe checkout condition. The counterexample demonstrates restraint about a new merchant. The current build passes 39 rule tests and 19 local browser checks. Those are software checks, not fraud detection precision or recall. Real-world fraud accuracy and user outcomes have not been measured.

**Does HTTPS mean safe?**

No. Encryption is one property of a connection, not seller verification. A malicious shop can use HTTPS. Meadow can miss sophisticated deception.

**What does it miss?**

Uncovered brands, convincing independent fake shops, script-controlled payment destinations, embedded checkout frames and merchant fulfilment can remain unverified. A PASS means the performed checks found no major warning, not that the store is safe.

**Does it read payment details?**

It checks field types and form destinations, not entered values. Page inspection and decisions run locally. If registration lookup is enabled, the registry receives the domain and the request’s network address. Avoid saying “nothing ever leaves the device” about the everyday build.

**Does it block payment?**

No. It provides evidence and warnings. The user decides. The demo fields are disabled for safety independently of the extension.

## Everyday use after presenting

Disable Demo Lab and re-enable/reload the live extension from `outputs/shopcheck/dist/shopcheck`. Refresh the shopping page. The live build excludes the simulated registration fixtures. The local demo server is not required for everyday use.
